# Choosing optimal lambda — iteration 6

Revises `choosing_optimal_lambda_bundle (2).zip` against the supplied `theorem_for_sam.pdf`. Both reference manuscripts remain unchanged. This version restores more of Sam's original motivation, the reason for selecting lambda through an alias budget, and the overlap-to-Fourier intuition. It retains the shorter technical explanations and increased paragraph spacing. The tail ratio rho is verified; the theorem now uses its simpler exact central denominator. Practical selection formulas and figures are unchanged from iteration 4.

- `choosing_optimal_lambda_section.pdf`: main section following Sam's argument sequence, with the error bound inline, no theorem box, and Khat notation.
- `choosing_optimal_lambda_review.pdf`: the section, the 2-by-4 figure, and appendix together.
- `choosing_optimal_lambda_appendix.pdf`: proofs, the logarithmic sensitivity argument, approximation conditions, and an implementable recipe.
- Matching `.tex` files: sources for insertion into the paper.
- `figures/lambda_rule_grid.pdf` and `.png`: vector and raster figures.
- `choose_lambda.py`: standalone basic/refined selection using only Python's standard library.
- `revision_notes.md`: mathematical compatibility and changes in this iteration.

The theorem bounds the actual finite-contour alias contribution for tanh modes and finite mixtures, including the factor two from boundary anchoring. The general rule retains the leading kernel dependence; the appendix proves when a frequency prefactor only modestly shifts the selected bandwidth. The representative frequency is a rough scale estimate, not a prescribed statistic. The practical refinement uses the explicit first-pair score and absorbs amplitude and anchoring constants into the effective tolerance. General activation predictors do not inherit the finite-contour tanh theorem.

The figure follows expC08's viridis plots, including full logarithmic axes and light grids. Left: N=32,64,128,256,512 at binary64. Right: p=16,24,32,40,48,53 at N=128. Both halves compare tanh and Gaussian for the sine mixture and 1/(1+25x^2). Green/basic and red/refined choices sit on measured error curves; their error coordinates are not theoretical predictions. The red choices have been recomputed from the current simplified rule. Observed source data are unchanged. No network fits were rerun.

## Use the recipe

```python
from choose_lambda import choose_lambda
from math import pi

# N=128 grid spacings on [-1,1], binary64 by default.
basic = choose_lambda("tanh", spacing=2/128)
refined = choose_lambda("tanh", spacing=2/128,
                        omega_scale=15*pi/7)
# Each returns lambda and gamma=lambda/spacing, plus search status.
```

The default `e_tol` is binary64 machine epsilon. Use `e_tol=2**-23` as a binary32 starting value, or choose another effective tolerance. The refinement needs only `omega_scale`, a rough angular frequency in radians per input unit (about 2*pi divided by a typical wavelength). Amplitude and fixed constants are assumed into `e_tol`; there is no separate amplitude input. A search-limit result is not a located threshold. Representation-theorem admissibility must still be checked separately.

## Reproduce the documents and figures

Python dependencies: `mpmath`, `numpy`, `scipy`, `matplotlib`, and `pypdf`. A LaTeX engine (`pdflatex` or `tectonic`) is required for PDFs.

```sh
python reproduce_figures.py
python check_math.py
python build_review.py
```

Alternatively specify `python build_review.py --engine /path/to/tectonic`. The builder checks overfull boxes and unresolved references, and records the actual page counts in `verification.json`; it imposes no main-section page target.

High-precision checks cover the replica/pole bridge, tail bound, normalized small-angle limit, logarithmic threshold sensitivity, and the standalone selector. They supplement the written proofs.
