"""Recompute the revised rule and redraw the existing least-squares observations.

This script fits no networks. Original source_data/anchor_rule_*.json files are
read-only inputs. Predictions use epsilon=2**(1-p), the original coefficient sum
S and weighted mean angular frequency, and a continuous root on [0.03, 1.5].
The revised practical alias score is twice the old compact first-pair score.
The tanh proof motivates that factor; the other activations remain predictors.
"""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from scipy.optimize import brentq

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "source_data"
OUT = ROOT / "figures"
ACTIVATIONS = ("tanh", "gelu", "swish", "gaussian")
ORDER = {"tanh": 1, "gelu": 2, "swish": 2, "gaussian": 0}
SEARCH = (0.03, 1.5)
ROOT_XTOL = 1e-13
TWO_PI = 2 * np.pi
BLUE, RED, BLACK = "#225EA8", "#C44936", "#30343B"


def log_h(activation, xi):
    """Log of the normalized transform magnitude H, without tail underflow."""
    xi = np.abs(np.asarray(xi, dtype=float))
    if activation == "gaussian":
        return -xi**2 / 4
    if activation == "gelu":
        return np.log1p(xi**2) - xi**2 / 2
    a = xi * (np.pi / 2 if activation == "tanh" else np.pi)
    nonzero = a > 0
    safe_a = np.where(nonzero, a, 1.0)
    log_one_minus = np.log(-np.expm1(-2 * safe_a))
    if activation == "tanh":
        value = np.log(2 * safe_a) - safe_a - log_one_minus
    elif activation == "swish":
        value = (2 * np.log(safe_a) - safe_a + np.log(2)
                 + np.log1p(np.exp(-2 * safe_a)) - 2 * log_one_minus)
    else:
        raise ValueError(activation)
    return np.where(nonzero, value, 0.0)


def log_refined_ratio(activation, lam, theta):
    """Log of R_new = 2 * (first pair)/(min{1,H})/(1-rho)."""
    if not 0 < theta < np.pi:
        raise ValueError("The representative grid frequency must lie in (0, pi).")
    r = ORDER[activation]
    first_minus = (r * np.log(theta / (TWO_PI - theta))
                   + log_h(activation, (TWO_PI - theta) / lam))
    first_plus = (r * np.log(theta / (TWO_PI + theta))
                  + log_h(activation, (TWO_PI + theta) / lam))
    denominator = np.minimum(0.0, log_h(activation, theta / lam))
    log_rho = (log_h(activation, (2 * TWO_PI - theta) / lam)
               - log_h(activation, (TWO_PI - theta) / lam))
    if np.any(log_rho >= 0):
        raise ValueError("The geometric alias correction requires rho < 1.")
    return (np.log(2) + np.logaddexp(first_minus, first_plus) - denominator
            - np.log(-np.expm1(log_rho)))


def largest_feasible(log_score, eps):
    """Continuous threshold, with search-limit status and a monotonicity check."""
    lo, hi = SEARCH
    grid = np.geomspace(lo, hi, 1001)
    values = np.asarray(log_score(grid), dtype=float)
    if not np.all(np.isfinite(values)):
        raise ValueError("Nonfinite alias score in the search interval.")
    # A numerical check over the stated interval guards these four built-ins;
    # it is not advertised as a monotonicity proof for arbitrary new kernels.
    if np.any(np.diff(values) < -1e-10):
        raise ValueError("The score is not numerically monotone on the search interval.")
    budget = np.log(eps)
    if values[0] > budget:
        return {"lambda": None, "status": "no_feasible_point"}
    if values[-1] <= budget:
        return {"lambda": hi, "status": "upper_search_limit"}
    root = brentq(lambda lam: float(log_score(lam) - budget), lo, hi,
                  xtol=ROOT_XTOL, rtol=1e-14)
    return {"lambda": float(root), "status": "root",
            "log_equation_residual": float(log_score(root) - budget)}


def make_predictions(original):
    inputs = {
        name: {"S": float(spec["B"]), "omega_mean": float(spec["omega_M"]),
               "source_convention": spec["how"]}
        for name, spec in original["spectral"].items()
    }
    prediction = {
        "version": "revised_factor_two_continuous_root",
        "precision": "epsilon_p=2**(1-p), spacing above one; not unit roundoff",
        "basic_formula": "H(2*pi/lambda) <= epsilon_p",
        "refined_formula": "S*2*(t_minus+t_plus)/min(1,H(theta/lambda))/(1-rho) <= epsilon_p",
        "terms": {"t_minus": "(theta/(2*pi-theta))**r * H((2*pi-theta)/lambda)",
                  "t_plus": "(theta/(2*pi+theta))**r * H((2*pi+theta)/lambda)",
                  "rho": "H((4*pi-theta)/lambda)/H((2*pi-theta)/lambda)",
                  "theta": "2*omega_mean/N"},
        "search": {"interval": list(SEARCH), "method": "scipy.optimize.brentq",
                   "xtol": ROOT_XTOL, "rtol": 1e-14,
                   "numerical_monotonicity_check": "1001 logarithmically spaced points",
                   "upper_search_limit_is_threshold": False},
        "scope": "Practical prediction range; the new tanh representation theorem additionally requires lambda<=1 and admissible width. A weighted mean is a practical spectral approximation. General kernels are predictors, not consequences of that tanh theorem.",
        "observations": "Original frozen-grid least-squares fits; no network was rerun.",
        "spectral": inputs, "width": {}, "precision": {},
    }
    for sweep in ("width", "precision"):
        for key in original[sweep]:
            activation, target, parameter = key.split("|")
            n, p = (int(parameter), 53) if sweep == "width" else (128, int(parameter))
            spec = inputs[target]
            eps = 2.0 ** (1-p)
            theta = 2 * spec["omega_mean"] / n
            basic = largest_feasible(lambda lam: log_h(activation, TWO_PI/lam), eps)
            if 0 < theta < np.pi:
                refined = largest_feasible(
                    lambda lam: np.log(spec["S"]) + log_refined_ratio(activation, lam, theta), eps)
            else:
                refined = {"lambda": None, "status": "frequency_outside_domain"}
            prediction[sweep][key] = {"N": n, "p": p, "epsilon": eps,
                                      "theta_mean": theta, "S": spec["S"],
                                      "basic": basic, "refined": refined}
    return prediction


def curve(rows, sweep, act, fn, n, p):
    points = sorted((r for r in rows[sweep] if r["act"] == act and r["fn"] == fn
                     and r["N"] == n and r["p"] == p), key=lambda r: r["lam"])
    return np.array([r["lam"] for r in points]), np.array([r["rel_l2"] for r in points])


def error_at(x, y, lam, smoothed=False):
    z = np.log10(np.maximum(y, 1e-300))
    if smoothed:
        z = np.array([np.median(z[max(0, i-2):min(len(z), i+3)]) for i in range(len(z))])
    return float(10**np.interp(math.log(lam), np.log(x), z))


def score(x, y, lam):
    z = np.log10(np.maximum(y, 1e-300))
    smoothed = np.array([np.median(z[max(0, i-2):min(len(z), i+3)]) for i in range(len(z))])
    return float(10**(np.interp(math.log(lam), np.log(x), smoothed) - np.min(smoothed)))


def draw_line(ax, prediction, color, style, **kwargs):
    # A capped point is a search boundary, not a located error transition.
    if prediction["status"] == "root":
        ax.axvline(prediction["lambda"], color=color, ls=style, **kwargs)


def save_figure(fig, stem):
    for suffix in ("png", "pdf"):
        fig.savefig(OUT / f"{stem}.{suffix}")
    plt.close(fig)


def draw_figures(prediction, rows):
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10,
                         "axes.titlesize": 11, "axes.labelsize": 10,
                         "axes.spines.top": False, "axes.spines.right": False,
                         "figure.dpi": 160, "savefig.dpi": 200})
    fig, axes = plt.subplots(2, 2, figsize=(10, 6.5), layout="constrained")
    for row, act in enumerate(("tanh", "gaussian")):
        for col, (fn, n, title) in enumerate((
                ("mix_1_3_5", 128, "Lower frequencies, N = 128"),
                ("mix_2_6_10", 32, "Higher frequencies, N = 32"))):
            ax = axes[row, col]
            x, y = curve(rows, "width", act, fn, n, 53)
            pr = prediction["width"][f"{act}|{fn}|{n}"]
            ax.semilogy(x, y, color=BLACK, lw=1.7)
            draw_line(ax, pr["basic"], BLUE, "--", lw=1.8)
            draw_line(ax, pr["refined"], RED, "-", lw=1.8)
            ax.set_xlim(0.1 if act == "tanh" else 0.3, 0.55 if act == "tanh" else 0.9)
            ax.set_ylim(max(1e-17, float(np.min(y))*0.3), min(2, float(np.max(y))*2))
            ax.grid(axis="y", alpha=.18)
            ax.set_title(f"{act.capitalize()}: {title}")
            ax.set_xlabel(r"$\lambda$")
            ax.set_ylabel("Relative sampled L2 error")
    fig.legend(handles=[Line2D([0], [0], color=BLACK, lw=1.7, label="Observed error"),
                        Line2D([0], [0], color=BLUE, ls="--", lw=1.8, label="Basic rule"),
                        Line2D([0], [0], color=RED, lw=1.8, label="Refined rule")],
               loc="outside upper center", ncol=3, frameon=False)
    save_figure(fig, "lambda_rule_comparison")

    fig, axes = plt.subplots(2, 2, figsize=(10, 6.7), layout="constrained")
    colors = {16: "#9467BD", 32: "#159895", 53: "#CE6B24"}
    for ax, act in zip(axes.flat, ACTIVATIONS):
        search_notes = []
        for p, color in colors.items():
            x, y = curve(rows, "precision", act, "mix_1_3_5", 128, p)
            pr = prediction["precision"][f"{act}|mix_1_3_5|{p}"]
            ax.semilogy(x, y, color=color, lw=1.3)
            draw_line(ax, pr["basic"], color, "--", lw=1.3, alpha=.85)
            draw_line(ax, pr["refined"], color, ":", lw=1.3, alpha=.85)
            for arm in ("basic", "refined"):
                if pr[arm]["status"] == "upper_search_limit":
                    search_notes.append((f"{p}-bit {arm}: search limit", color))
        for i, (label, color) in enumerate(search_notes):
            ax.text(.03, .97-.055*i, label, transform=ax.transAxes,
                    color=color, fontsize=9, va="top",
                    bbox={"facecolor": "white", "edgecolor": "none", "alpha": .9, "pad": 2})
        ax.set_title(act.upper() if act == "gelu" else act.capitalize())
        ax.set_xlabel(r"$\lambda$")
        ax.set_ylabel("Relative sampled L2 error")
        ax.grid(axis="y", alpha=.18)
        ax.set_ylim(1e-17, 2)
        ax.set_xlim(.1, 1.5)
    handles = [Line2D([0], [0], color=c, lw=2, label=f"{p} bits") for p, c in colors.items()]
    handles += [Line2D([0], [0], color=BLACK, ls="--", label="Basic prediction"),
                Line2D([0], [0], color=BLACK, ls=":", label="Refined prediction")]
    fig.legend(handles=handles, loc="outside upper center", ncol=5, frameon=False)
    save_figure(fig, "lambda_precision_comparison")


def summarize(prediction, rows):
    summary, selected, displayed_precision = {}, [], []
    for sweep in ("width", "precision"):
        for act in ACTIVATIONS:
            values = []
            for key, pr in prediction[sweep].items():
                a, fn, _ = key.split("|")
                if a != act or any(pr[arm]["status"] != "root" for arm in ("basic", "refined")):
                    continue
                x, y = curve(rows, sweep, a, fn, pr["N"], pr["p"])
                values.append([score(x, y, pr[arm]["lambda"]) for arm in ("basic", "refined")])
            ar = np.asarray(values)
            summary[f"{sweep}:{act}"] = {
                "n": len(values), "basic_median": float(np.median(ar[:, 0])),
                "refined_median": float(np.median(ar[:, 1])),
                "basic_p90": float(np.quantile(ar[:, 0], .9)),
                "refined_p90": float(np.quantile(ar[:, 1], .9))}
    for act in ("tanh", "gaussian"):
        for fn, n in (("mix_1_3_5", 128), ("mix_2_6_10", 32)):
            pr = prediction["width"][f"{act}|{fn}|{n}"]
            x, y = curve(rows, "width", act, fn, n, 53)
            selected.append({"act": act, "fn": fn, **pr,
                             **{f"{arm}_score": score(x, y, pr[arm]["lambda"])
                                for arm in ("basic", "refined")},
                             **{f"{arm}_interpolated_error": error_at(x, y, pr[arm]["lambda"])
                                for arm in ("basic", "refined")}})
    for act in ACTIVATIONS:
        for p in (16, 32, 53):
            displayed_precision.append({"act": act, **prediction["precision"][f"{act}|mix_1_3_5|{p}"]})
    counts = {}
    for sweep in ("width", "precision"):
        counts[sweep] = {}
        for arm in ("basic", "refined"):
            statuses = [pr[arm]["status"] for pr in prediction[sweep].values()]
            counts[sweep][arm] = {status: statuses.count(status) for status in sorted(set(statuses))}
    return {"source": "Original anchor_rule_2026-09-09 observed fits; revised predictions",
            "metric": "Five-point median log error; interpolation in log lambda; ratio to minimum of same smoothed 40-point curve; common uncapped cases. Raw interpolated errors use the unsmoothed curve.",
            "summary": summary, "selected": selected, "displayed_precision": displayed_precision,
            "prediction_status_counts": counts}


def main():
    original_paths = [DATA / "anchor_rule_predictions_mean.json"] + [
        DATA / f"anchor_rule_rows_{sweep}.json" for sweep in ("width", "precision")]
    hashes_before = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in original_paths}
    original = json.loads(original_paths[0].read_text())
    rows = {sweep: json.loads((DATA / f"anchor_rule_rows_{sweep}.json").read_text())
            for sweep in ("width", "precision")}
    prediction = make_predictions(original)
    prediction["original_input_sha256"] = hashes_before
    (DATA / "revised_rule_predictions.json").write_text(json.dumps(prediction, indent=2, allow_nan=False) + "\n")
    OUT.mkdir(exist_ok=True)
    draw_figures(prediction, rows)
    statistics = summarize(prediction, rows)
    statistics["original_input_sha256"] = hashes_before
    (OUT / "figure_statistics.json").write_text(json.dumps(statistics, indent=2, allow_nan=False) + "\n")
    hashes_after = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in original_paths}
    if hashes_before != hashes_after:
        raise RuntimeError("An original input file changed.")
    print(json.dumps({"selected": statistics["selected"],
                      "displayed_precision": statistics["displayed_precision"],
                      "status_counts": statistics["prediction_status_counts"],
                      "original_inputs_unchanged": True}, indent=2))


if __name__ == "__main__":
    main()
