"""Build the paired LaTeX sections and verify the one-page main section."""
from pathlib import Path
import argparse
import json
import shutil
import subprocess
from pypdf import PdfReader, PdfWriter

ROOT = Path(__file__).resolve().parent

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--engine', help='Path to pdflatex or tectonic; otherwise search PATH')
    args = parser.parse_args()
    engine = args.engine or shutil.which('pdflatex') or shutil.which('tectonic')
    if not engine:
        raise SystemExit('A LaTeX engine is required: pdflatex or tectonic.')
    build = ROOT/'build'
    build.mkdir(exist_ok=True)
    if 'tectonic' in Path(engine).name:
        command = [engine, '--untrusted', '--keep-logs', '--keep-intermediates',
                   '--outdir', str(build), 'review_document.tex']
        passes = 1
    else:
        command = [engine, '-interaction=nonstopmode', '-halt-on-error',
                   '-output-directory='+str(build), 'review_document.tex']
        passes = 2
    for _ in range(passes):
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
        if result.returncode:
            raise RuntimeError((result.stdout+result.stderr)[-6000:])
    log = (build/'review_document.log').read_text()
    problems = [word for word in ['Overfull', 'undefined references',
                                  'multiply defined', 'Missing character'] if word in log]
    if problems:
        raise RuntimeError('Typesetting needs review: '+', '.join(problems))
    combined = ROOT/'choosing_optimal_lambda_review.pdf'
    shutil.copyfile(build/'review_document.pdf', combined)
    reader = PdfReader(combined)
    texts = [p.extract_text() for p in reader.pages]
    assert 'More speci' in texts[0], 'Main subsection exceeds one page'
    assert 'bandwidth' in texts[0].lower()
    appendix_start = next(i for i, text in enumerate(texts) if 'Proof and interpretation' in text)
    assert appendix_start == 2, 'Expected one main page and one width-figure page'
    preview = PdfWriter()
    preview.add_page(reader.pages[0])
    if '/Annots' in preview.pages[0]:
        del preview.pages[0]['/Annots']
    preview.add_metadata({'/Title': 'Choosing the bandwidth: one-page subsection'})
    with (ROOT/'choosing_optimal_lambda_one_page.pdf').open('wb') as out:
        preview.write(out)
    appendix = PdfWriter()
    for page in reader.pages[appendix_start:]:
        appendix.add_page(page)
    with (ROOT/'choosing_optimal_lambda_appendix.pdf').open('wb') as out:
        appendix.write(out)
    math_checks = json.loads((ROOT/'figures/mathematical_checks.json').read_text())
    report = {
        'main_pages': 1, 'main_words_extracted': len(texts[0].split()),
        'width_figure_pages': 1, 'appendix_pages_including_precision_figure': len(texts)-appendix_start,
        'total_pages': len(texts), 'text_size_pt': 11,
        'overfull_boxes': False, 'unresolved_references': False,
        'main_first_pair_bound': True, 'appendix_lemmas': 3,
        'reference_papers_edited': False, 'network_fits_rerun': False,
        'prediction_lines': 'Recomputed using the revised formulas',
        'mathematics': math_checks,
    }
    (ROOT/'verification.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))

if __name__ == '__main__':
    main()
