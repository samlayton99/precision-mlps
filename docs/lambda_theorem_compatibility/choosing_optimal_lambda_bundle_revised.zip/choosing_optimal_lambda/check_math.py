from decimal import Decimal as D, getcontext
import json
from pathlib import Path
getcontext().prec=70
getcontext().Emin=-9999999
getcontext().Emax=9999999
pi=D('3.141592653589793238462643383279502884197169399375105820974944592307816406286')
def sinh(x):return (x.exp()-(-x).exp())/2
def cosh(x):return (x.exp()+(-x).exp())/2
H={'tanh':lambda x:(pi*x/2)/sinh(pi*x/2) if x else D(1),'gelu':lambda x:(1+x*x)*(-x*x/2).exp(),'swish':lambda x:(pi*x)**2*cosh(pi*x)/sinh(pi*x)**2 if x else D(1),'gaussian':lambda x:(-x*x/4).exp()}
orders={'tanh':1,'gelu':2,'swish':2,'gaussian':0}
count=0
for name,h in H.items():
 for lam in map(D,['0.12','0.25','0.7','1.5']):
  for th in [D(0),D('.1'),D('.8'),D('2.5'),pi-D('.01')]:
   vals=[(k,h(abs(th+2*pi*k)/lam)/h(th/lam)) for k in list(range(-50,0))+list(range(1,51))]
   rho=h((4*pi-th)/lam)/h((2*pi-th)/lam)
   for r in set([0,orders[name]]):
    exact=sum(a*((abs(th/(th+2*pi*k)))**r if r else 1) for k,a in vals)
    pair=sum((th/(2*pi+sign*th))**r*h((2*pi+sign*th)/lam) for sign in [-1,1]) if r else h((2*pi-th)/lam)+h((2*pi+th)/lam)
    bound=pair/((1-rho)*min(h(D(0)),h(th/lam)))
    assert exact<=bound*(1+D('1e-60')),(name,lam,th,r)
    count+=1
for lam in map(D,['.25','.5','1.2']):
 for th in map(D,['.03','.3','2.0']):
  h=H['gaussian'];pair=(h((2*pi-th)/lam)+h((2*pi+th)/lam))/h(th/lam)
  zero=2*h(2*pi/lam);rhs=cosh(pi*th/lam**2)
  assert abs(pair/zero/rhs-1)<D('1e-60')
import mpmath as mp
mp.mp.dps=85
def full_tanh(lam,theta):
 s=mp.pi*theta/(2*lam);a=mp.pi**2/lam
 return mp.sinh(s)*mp.fsum(mp.csch(m*a-s)+mp.csch(m*a+s) for m in range(1,81))
def direct_pole(lam,theta,layers,u):
 h=mp.mpf(1)/16;g=lam/h;d=mp.pi/(2*g);x0=-mp.mpf(1);x=x0+h*u;w0=theta/h
 def density(z):return (mp.exp(1j*w0*(z+1j*d))-mp.exp(1j*w0*(z-1j*d)))/(2j*d)
 terms=[]
 for ell in range(layers):
  for sign in [-1,1]:
   for loc,res in [(x,-1/(2*g)),(x0,1/(2*g))]:
    p=loc+sign*1j*(2*ell+1)*d;w=mp.exp(2j*mp.pi*(p-x0)/h)
    rh=w/(w-1) if sign==1 else 1/(w-1)
    terms.append(rh*res*density(p))
 return 2j*mp.pi*mp.fsum(terms)
series_checks=direct_checks=density_checks=0
max_fraction=mp.mpf(0)
for lam in map(mp.mpf,['.12','.25','.7','1']):
 for theta in map(mp.mpf,['.03','.7','2.5']):
  s=mp.pi*theta/(2*lam);a=mp.pi**2/lam
  spectral=full_tanh(lam,theta)
  poles=4*mp.sinh(s)*mp.fsum(mp.cosh((2*ell+1)*s)/mp.expm1((2*ell+1)*a) for ell in range(80))
  assert abs(spectral/poles-1)<mp.mpf('1e-65')
  series_checks+=1
  # Compute the complex-shift density independently of its Fourier multiplier.
  h=mp.mpf(1)/16;g=lam/h;d=mp.pi/(2*g);omega=theta/h;z=mp.mpf('.37')
  density=(mp.exp(1j*omega*(z+1j*d))-mp.exp(1j*omega*(z-1j*d)))/(2j*d)
  desired=1j*omega*mp.exp(1j*omega*z)
  assert abs(density*(s/mp.sinh(s))/desired-1)<mp.mpf('1e-70')
  density_checks+=1
  for layers in [1,2,3]:
   for u in map(mp.mpf,['.17','.5','.83']):
    fraction=abs(direct_pole(lam,theta,layers,u))/(2*spectral)
    assert fraction<=1+mp.mpf('1e-65')
    max_fraction=max(max_fraction,fraction);direct_checks+=1
a=4*mp.pi**2
basic=a/mp.sinh(a)
certified=4*mp.exp(-a)/((1-mp.exp(-a))*(1-mp.exp(-2*a)))
assert certified<mp.mpf(2)**-53 and basic>mp.mpf(2)**-52
root_lambda=mp.findroot(lambda l:mp.pi**2/l/mp.sinh(mp.pi**2/l)-mp.mpf(2)**-52,(mp.mpf('.243'),mp.mpf('.245')))
root=Path(__file__).resolve().parent
out={'status':'passed','numeric_tail_checks':count,'precision_decimal_digits':70,
     'bridge_decimal_digits':mp.mp.dps,'replica_residue_series_checks':series_checks,
     'deconvolution_checks':density_checks,'direct_signed_pole_checks':direct_checks,
     'largest_direct_pole_fraction_of_bound':float(max_fraction),
     'basic_score_at_quarter':float(basic),'class_replica_bound_over_B_at_quarter':float(certified),
     'basic_epsilon_root':float(root_lambda),
     'note':'Tail checks S<=old_R are equivalent to 2S<=revised_R. Numerical checks support, but do not replace, the written proofs.'}
(root/'figures/mathematical_checks.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out))
