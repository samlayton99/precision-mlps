"""Recompute the revised rule and redraw the existing least-squares observations.

This script fits no networks. Original source_data/anchor_rule_*.json files are
read-only inputs. Predictions use epsilon=2**(1-p), the original coefficient sum
S and weighted mean angular frequency, and a continuous root on [0.03, 1.5].
The revised practical alias score is twice the old compact first-pair score.
The tanh proof motivates that factor; the other activations remain predictors.
"""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from scipy.optimize import brentq

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "source_data"
OUT = ROOT / "figures"
ACTIVATIONS = ("tanh", "gelu", "swish", "gaussian")
ORDER = {"tanh": 1, "gelu": 2, "swish": 2, "gaussian": 0}
SEARCH = (0.03, 1.5)
ROOT_XTOL = 1e-13
TWO_PI = 2 * np.pi
GREEN, RED = "#21864B", "#C63839"
CURVE_COLORS = ("#A5B5C8", "#647D9C", "#233F65")
DISPLAY_ACTIVATIONS = ("tanh", "gaussian")
DISPLAY_TARGETS = ("mix_1_3_5", "runge25")
DISPLAY_WIDTHS = (32, 128, 512)
DISPLAY_PRECISIONS = (16, 32, 53)


def log_h(activation, xi):
    """Log of the normalized transform magnitude H, without tail underflow."""
    xi = np.abs(np.asarray(xi, dtype=float))
    if activation == "gaussian":
        return -xi**2 / 4
    if activation == "gelu":
        return np.log1p(xi**2) - xi**2 / 2
    a = xi * (np.pi / 2 if activation == "tanh" else np.pi)
    nonzero = a > 0
    safe_a = np.where(nonzero, a, 1.0)
    log_one_minus = np.log(-np.expm1(-2 * safe_a))
    if activation == "tanh":
        value = np.log(2 * safe_a) - safe_a - log_one_minus
    elif activation == "swish":
        value = (2 * np.log(safe_a) - safe_a + np.log(2)
                 + np.log1p(np.exp(-2 * safe_a)) - 2 * log_one_minus)
    else:
        raise ValueError(activation)
    return np.where(nonzero, value, 0.0)


def log_refined_ratio(activation, lam, theta):
    """Log of R_new = 2 * (first pair)/(min{1,H})/(1-rho)."""
    if not 0 < theta < np.pi:
        raise ValueError("The representative grid frequency must lie in (0, pi).")
    r = ORDER[activation]
    first_minus = (r * np.log(theta / (TWO_PI - theta))
                   + log_h(activation, (TWO_PI - theta) / lam))
    first_plus = (r * np.log(theta / (TWO_PI + theta))
                  + log_h(activation, (TWO_PI + theta) / lam))
    denominator = np.minimum(0.0, log_h(activation, theta / lam))
    log_rho = (log_h(activation, (2 * TWO_PI - theta) / lam)
               - log_h(activation, (TWO_PI - theta) / lam))
    if np.any(log_rho >= 0):
        raise ValueError("The geometric alias correction requires rho < 1.")
    return (np.log(2) + np.logaddexp(first_minus, first_plus) - denominator
            - np.log(-np.expm1(log_rho)))


def largest_feasible(log_score, eps):
    """Continuous threshold, with search-limit status and a monotonicity check."""
    lo, hi = SEARCH
    grid = np.geomspace(lo, hi, 1001)
    values = np.asarray(log_score(grid), dtype=float)
    if not np.all(np.isfinite(values)):
        raise ValueError("Nonfinite alias score in the search interval.")
    # A numerical check over the stated interval guards these four built-ins;
    # it is not advertised as a monotonicity proof for arbitrary new kernels.
    if np.any(np.diff(values) < -1e-10):
        raise ValueError("The score is not numerically monotone on the search interval.")
    budget = np.log(eps)
    if values[0] > budget:
        return {"lambda": None, "status": "no_feasible_point"}
    if values[-1] <= budget:
        return {"lambda": hi, "status": "upper_search_limit"}
    root = brentq(lambda lam: float(log_score(lam) - budget), lo, hi,
                  xtol=ROOT_XTOL, rtol=1e-14)
    return {"lambda": float(root), "status": "root",
            "log_equation_residual": float(log_score(root) - budget)}


def make_predictions(original):
    inputs = {
        name: {"S": float(spec["B"]), "omega_mean": float(spec["omega_M"]),
               "source_convention": spec["how"]}
        for name, spec in original["spectral"].items()
    }
    prediction = {
        "version": "revised_factor_two_continuous_root",
        "precision": "epsilon_p=2**(1-p), spacing above one; not unit roundoff",
        "basic_formula": "H(2*pi/lambda) <= epsilon_p",
        "refined_formula": "S*2*(t_minus+t_plus)/min(1,H(theta/lambda))/(1-rho) <= epsilon_p",
        "terms": {"t_minus": "(theta/(2*pi-theta))**r * H((2*pi-theta)/lambda)",
                  "t_plus": "(theta/(2*pi+theta))**r * H((2*pi+theta)/lambda)",
                  "rho": "H((4*pi-theta)/lambda)/H((2*pi-theta)/lambda)",
                  "theta": "2*omega_mean/N"},
        "search": {"interval": list(SEARCH), "method": "scipy.optimize.brentq",
                   "xtol": ROOT_XTOL, "rtol": 1e-14,
                   "numerical_monotonicity_check": "1001 logarithmically spaced points",
                   "upper_search_limit_is_threshold": False},
        "scope": "Practical prediction range; the new tanh representation theorem additionally requires lambda<=1 and admissible width. A weighted mean is a practical spectral approximation. General kernels are predictors, not consequences of that tanh theorem.",
        "observations": "Original frozen-grid least-squares fits; no network was rerun.",
        "spectral": inputs, "width": {}, "precision": {},
    }
    for sweep in ("width", "precision"):
        for key in original[sweep]:
            activation, target, parameter = key.split("|")
            n, p = (int(parameter), 53) if sweep == "width" else (128, int(parameter))
            spec = inputs[target]
            eps = 2.0 ** (1-p)
            theta = 2 * spec["omega_mean"] / n
            basic = largest_feasible(lambda lam: log_h(activation, TWO_PI/lam), eps)
            if 0 < theta < np.pi:
                refined = largest_feasible(
                    lambda lam: np.log(spec["S"]) + log_refined_ratio(activation, lam, theta), eps)
            else:
                refined = {"lambda": None, "status": "frequency_outside_domain"}
            prediction[sweep][key] = {"N": n, "p": p, "epsilon": eps,
                                      "theta_mean": theta, "S": spec["S"],
                                      "basic": basic, "refined": refined}
    return prediction


def curve(rows, sweep, act, fn, n, p):
    points = sorted((r for r in rows[sweep] if r["act"] == act and r["fn"] == fn
                     and r["N"] == n and r["p"] == p), key=lambda r: r["lam"])
    return np.array([r["lam"] for r in points]), np.array([r["rel_l2"] for r in points])


def error_at(x, y, lam, smoothed=False):
    z = np.log10(np.maximum(y, 1e-300))
    if smoothed:
        z = np.array([np.median(z[max(0, i-2):min(len(z), i+3)]) for i in range(len(z))])
    return float(10**np.interp(math.log(lam), np.log(x), z))


def score(x, y, lam):
    z = np.log10(np.maximum(y, 1e-300))
    smoothed = np.array([np.median(z[max(0, i-2):min(len(z), i+3)]) for i in range(len(z))])
    return float(10**(np.interp(math.log(lam), np.log(x), smoothed) - np.min(smoothed)))


def draw_line(ax, prediction, color, style, **kwargs):
    # A capped point is a search boundary, not a located error transition.
    if prediction["status"] == "root":
        ax.axvline(prediction["lambda"], color=color, ls=style, **kwargs)


def save_figure(fig, stem):
    for suffix in ("png", "pdf"):
        fig.savefig(OUT / f"{stem}.{suffix}")
    plt.close(fig)


def draw_figures(prediction, rows):
    """Two rows of targets, with two activation columns in each sweep block.

    Exactly two prediction traces per panel connect the selected points on the
    measured curves. Their x-coordinates are predicted; their y-coordinates are
    measured-error interpolation, not a theoretical error prediction.
    """
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9,
                         "axes.titlesize": 10, "axes.labelsize": 9,
                         "axes.spines.top": False, "axes.spines.right": False,
                         "figure.dpi": 170, "savefig.dpi": 220,
                         "pdf.fonttype": 42})
    fig, axes = plt.subplots(2, 4, figsize=(14, 7.0), sharey=True)
    fig.subplots_adjust(left=.062, right=.988, bottom=.115, top=.78,
                        wspace=.21, hspace=.31)
    displayed = []
    for row, target in enumerate(DISPLAY_TARGETS):
        for block, sweep in enumerate(("width", "precision")):
            parameters = DISPLAY_WIDTHS if sweep == "width" else DISPLAY_PRECISIONS
            for local_col, act in enumerate(DISPLAY_ACTIVATIONS):
                col = 2*block+local_col
                ax = axes[row, col]
                traces = {"basic": [], "refined": []}
                for value, color in zip(parameters, CURVE_COLORS):
                    n, p = (value, 53) if sweep == "width" else (128, value)
                    x, y = curve(rows, sweep, act, target, n, p)
                    if len(x) != 40:
                        raise ValueError("The display requires the original complete 40-point curve.")
                    ax.semilogy(x, y, color=color, lw=1.45, zorder=2)
                    key = f"{act}|{target}|{value}"
                    pr = prediction[sweep][key]
                    for arm in ("basic", "refined"):
                        if pr[arm]["status"] != "root":
                            raise ValueError(f"Unlocated prediction in display: {sweep}, {key}, {arm}")
                        lam = pr[arm]["lambda"]
                        measured = error_at(x, y, lam)
                        traces[arm].append((lam, measured))
                        displayed.append({"sweep": sweep, "act": act, "fn": target,
                                          "N": n, "p": p, "rule": arm,
                                          "predicted_lambda": lam,
                                          "measured_error_at_prediction": measured})
                for arm, color, marker in [("basic", GREEN, "o"), ("refined", RED, "D")]:
                    points = np.asarray(traces[arm])
                    ax.plot(points[:, 0], points[:, 1], color=color, lw=1.8,
                            marker=marker, markersize=4.2, markerfacecolor="white",
                            markeredgewidth=1.25, zorder=5)
                if sweep == "width":
                    ax.set_xlim((.09, .58) if act == "tanh" else (.28, .91))
                    ax.set_xticks([.1, .25, .4, .55] if act == "tanh" else [.3, .5, .7, .9])
                else:
                    ax.set_xlim((.12, 1.03) if act == "tanh" else (.3, 1.12))
                    ax.set_xticks([.2, .4, .6, .8, 1] if act == "tanh" else [.4, .6, .8, 1])
                ax.set_ylim(2e-17, 1.5)
                ax.set_yticks([1e-16, 1e-12, 1e-8, 1e-4, 1])
                ax.grid(axis="y", color="#D9DFE5", alpha=.7, linewidth=.55)
                ax.tick_params(axis="both", labelsize=8, length=3, width=.65)
                if local_col == 0:
                    ax.set_ylabel(r"$f_%d$: relative $L^2$ error" % (row+1))
                    ax.tick_params(axis="y", labelleft=True)
                else:
                    ax.tick_params(axis="y", labelleft=False)
                if row == 1:
                    ax.set_xlabel(r"$\lambda$", labelpad=2)
                ax.set_title(("Tanh" if act == "tanh" else "Gaussian")
                             + r" $\vert$ $f_%d$" % (row+1), pad=7)
    left_center = (axes[0,0].get_position().x0+axes[0,1].get_position().x1)/2
    right_center = (axes[0,2].get_position().x0+axes[0,3].get_position().x1)/2
    fig.text(left_center, .954, r"Width sweep  $\vert$  $\varepsilon=2^{-52}$",
             ha="center", va="top", fontsize=12, weight="bold")
    fig.text(right_center, .954, r"Precision sweep  $\vert$  $N=128$",
             ha="center", va="top", fontsize=12, weight="bold")
    for center, values, labels in [
        (left_center, DISPLAY_WIDTHS, [rf"$N={n}$" for n in DISPLAY_WIDTHS]),
        (right_center, DISPLAY_PRECISIONS, [rf"$p={p}$" for p in DISPLAY_PRECISIONS])]:
        handles = [Line2D([0],[0],color=c,lw=2,label=label)
                   for c,label in zip(CURVE_COLORS,labels)]
        fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(center,.912),
                   ncol=3, frameon=False, fontsize=9, handlelength=2.2, columnspacing=1.5)
    rule_handles = [Line2D([0],[0],color=GREEN,lw=1.8,marker="o",mfc="white",label="Basic rule"),
                    Line2D([0],[0],color=RED,lw=1.8,marker="D",mfc="white",label="Refined rule")]
    fig.legend(handles=rule_handles, loc="upper center", bbox_to_anchor=(.52,.858),
               ncol=2, frameon=False, fontsize=10, columnspacing=3, handlelength=2.6)
    divider = (axes[0,1].get_position().x1+axes[0,2].get_position().x0)/2
    fig.add_artist(Line2D([divider,divider],[.085,.97],transform=fig.transFigure,
                         color="#DBE1E7",lw=.9,zorder=0))
    fig.text(.265,.03,r"$f_1(x)=\sin(\pi x)+\frac{1}{2}\sin(3\pi x)+\frac{1}{4}\sin(5\pi x)$",
             ha="center",va="center",fontsize=10)
    fig.text(.765,.03,r"$f_2(x)=\frac{1}{1+25x^2}$",
             ha="center",va="center",fontsize=10)
    save_figure(fig,"lambda_rule_grid")
    (OUT/"figure_layout.json").write_text(json.dumps({
        "shape":[2,4], "rows":list(DISPLAY_TARGETS),
        "columns":["width:tanh","width:gaussian","precision:tanh","precision:gaussian"],
        "widths":list(DISPLAY_WIDTHS), "precision_bits":list(DISPLAY_PRECISIONS),
        "basic_color":GREEN, "refined_color":RED,
        "prediction_trace":"Connect predicted lambda choices on their corresponding observed error curves; y is measured, not predicted.",
        "points":displayed},indent=2)+"\n")


def summarize(prediction, rows):
    summary, selected, displayed_precision = {}, [], []
    for sweep in ("width", "precision"):
        for act in ACTIVATIONS:
            values = []
            for key, pr in prediction[sweep].items():
                a, fn, _ = key.split("|")
                if a != act or any(pr[arm]["status"] != "root" for arm in ("basic", "refined")):
                    continue
                x, y = curve(rows, sweep, a, fn, pr["N"], pr["p"])
                values.append([score(x, y, pr[arm]["lambda"]) for arm in ("basic", "refined")])
            ar = np.asarray(values)
            summary[f"{sweep}:{act}"] = {
                "n": len(values), "basic_median": float(np.median(ar[:, 0])),
                "refined_median": float(np.median(ar[:, 1])),
                "basic_p90": float(np.quantile(ar[:, 0], .9)),
                "refined_p90": float(np.quantile(ar[:, 1], .9))}
    for act in DISPLAY_ACTIVATIONS:
        for fn, n in ((f, n) for f in DISPLAY_TARGETS for n in DISPLAY_WIDTHS):
            pr = prediction["width"][f"{act}|{fn}|{n}"]
            x, y = curve(rows, "width", act, fn, n, 53)
            selected.append({"act": act, "fn": fn, **pr,
                             **{f"{arm}_score": score(x, y, pr[arm]["lambda"])
                                for arm in ("basic", "refined")},
                             **{f"{arm}_interpolated_error": error_at(x, y, pr[arm]["lambda"])
                                for arm in ("basic", "refined")}})
    for act in DISPLAY_ACTIVATIONS:
        for fn in DISPLAY_TARGETS:
            for p in DISPLAY_PRECISIONS:
                displayed_precision.append({"act": act, "fn": fn, **prediction["precision"][f"{act}|{fn}|{p}"]})
    counts = {}
    for sweep in ("width", "precision"):
        counts[sweep] = {}
        for arm in ("basic", "refined"):
            statuses = [pr[arm]["status"] for pr in prediction[sweep].values()]
            counts[sweep][arm] = {status: statuses.count(status) for status in sorted(set(statuses))}
    return {"source": "Original anchor_rule_2026-09-09 observed fits; revised predictions",
            "metric": "Five-point median log error; interpolation in log lambda; ratio to minimum of same smoothed 40-point curve; common uncapped cases. Raw interpolated errors use the unsmoothed curve.",
            "summary": summary, "selected": selected, "displayed_precision": displayed_precision,
            "prediction_status_counts": counts}


def main():
    original_paths = [DATA / "anchor_rule_predictions_mean.json"] + [
        DATA / f"anchor_rule_rows_{sweep}.json" for sweep in ("width", "precision")]
    hashes_before = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in original_paths}
    original = json.loads(original_paths[0].read_text())
    rows = {sweep: json.loads((DATA / f"anchor_rule_rows_{sweep}.json").read_text())
            for sweep in ("width", "precision")}
    prediction = make_predictions(original)
    prediction["original_input_sha256"] = hashes_before
    (DATA / "revised_rule_predictions.json").write_text(json.dumps(prediction, indent=2, allow_nan=False) + "\n")
    OUT.mkdir(exist_ok=True)
    draw_figures(prediction, rows)
    statistics = summarize(prediction, rows)
    statistics["original_input_sha256"] = hashes_before
    (OUT / "figure_statistics.json").write_text(json.dumps(statistics, indent=2, allow_nan=False) + "\n")
    hashes_after = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in original_paths}
    if hashes_before != hashes_after:
        raise RuntimeError("An original input file changed.")
    print(json.dumps({"figure": "lambda_rule_grid", "shape": [2, 4],
                      "widths": DISPLAY_WIDTHS, "precisions": DISPLAY_PRECISIONS,
                      "original_inputs_unchanged": True}, indent=2))


if __name__ == "__main__":
    main()
