# Choosing optimal lambda — iteration 2

Revised from `choosing_optimal_lambda_bundle (2).zip` against the supplied September 13, 2026 `theorem_for_sam.pdf`. Both reference manuscripts remain unchanged.

- `choosing_optimal_lambda_one_page.pdf`: the main subsection, including the compact first-pair theorem and both selection rules.
- `choosing_optimal_lambda_appendix.pdf`: three proof lemmas, the width-limit justification, intuition, and the budget argument.
- `choosing_optimal_lambda_review.pdf`: subsection, the landscape comparison figure, and appendix together.
- `choosing_optimal_lambda.tex`, `choosing_optimal_lambda_appendix.tex`: LaTeX sources for insertion into the paper.
- `choosing_optimal_lambda_figures.tex`: eight-panel comparison figure and caption.
- `revision_notes.md`: what changed with the new foundation and why.

The main theorem now bounds the actual finite-contour replica contribution for tanh Fourier modes and finite mixtures. Its compact ratio includes the factor two from boundary anchoring. General targets retain the new proof's local-analytic replica guarantee; the mean-frequency substitution is identified as a practical approximation.

The 2-by-4 figure uses tanh and Gaussian with a sine mixture and the nonoscillatory target 1/(1+25x^2). Its left four panels vary N=32,128,512 at binary64 precision; its right four vary p=16,32,53 at N=128. Green and red lines connect basic and refined bandwidth choices on the measured curves. Their horizontal coordinates are predicted bandwidths; their vertical coordinates are interpolated observed errors. The figure reuses the original measured least-squares curves. Original source data are retained unchanged in `source_data/`. The predictions and numerical root checks are in `source_data/revised_rule_predictions.json`; the displayed marker coordinates and layout are in `figures/figure_layout.json`. The full-size figure is `figures/lambda_rule_grid.pdf` or `.png`.

## Reproduce

Python dependencies: `mpmath`, `numpy`, `scipy`, `matplotlib`, and `pypdf`. A LaTeX engine (`pdflatex` or `tectonic`) is required for the PDFs.

```sh
python check_math.py
python reproduce_figures.py
python build_review.py
```

Alternatively specify `python build_review.py --engine /path/to/tectonic`. The builder rejects an overfull box, missing references, or a main subsection longer than one page. `verification.json` records the actual results. The manuscript format may require its own page-layout check when the subsection is inserted.

`check_math.py` uses 70-digit tail checks and 85-digit checks of deconvolution, the replica/residue identity, and direct signed finite-contour pole sums. These support the written proofs; they do not replace them.
