# Choosing optimal lambda — iteration 3

Revises `choosing_optimal_lambda_bundle (2).zip` against the supplied `theorem_for_sam.pdf`. Both reference manuscripts remain unchanged.

- `choosing_optimal_lambda_section.pdf`: main section following Sam's argument sequence, with the error bound inline, no theorem box, and Khat notation.
- `choosing_optimal_lambda_review.pdf`: the section, the 2-by-4 figure, and appendix together.
- `choosing_optimal_lambda_appendix.pdf`: proofs, the logarithmic sensitivity argument, approximation conditions, and an implementable recipe.
- Matching `.tex` files: sources for insertion into the paper.
- `figures/lambda_rule_grid.pdf` and `.png`: vector and raster figures.
- `choose_lambda.py`: standalone basic/refined selection using only Python's standard library.
- `revision_notes.md`: mathematical compatibility and changes in this iteration.

The theorem bounds the actual finite-contour alias contribution for tanh modes and finite mixtures, including the factor two from boundary anchoring. The general rule retains the leading kernel dependence; the appendix proves when a frequency prefactor only modestly shifts the selected bandwidth. The mean-frequency substitution is a practical approximation, with a leading-order justification for well-resolved tanh mixtures. General activation predictors do not inherit the finite-contour tanh theorem.

The figure follows expC08's viridis plots, including full logarithmic axes and light grids. Left: N=32,64,128,256,512 at binary64. Right: p=16,24,32,40,48,53 at N=128. Both halves compare tanh and Gaussian for the sine mixture and 1/(1+25x^2). Green/basic and red/refined choices sit on measured error curves; their error coordinates are not theoretical predictions. Observed source data are unchanged. No network fits were rerun.

## Use the recipe

```python
from choose_lambda import choose_lambda
from math import pi

# N=128 grid spacings on [-1,1], binary64 by default.
basic = choose_lambda("tanh", spacing=2/128)
refined = choose_lambda("tanh", spacing=2/128,
                        spectral_mass=7/4, mean_omega=15*pi/7)
# Each returns lambda and gamma=lambda/spacing, plus search status.
```

Use `epsilon=2**-23` for binary32. Frequencies are angular frequencies in radians per input unit. The refinement uses mass/output_scale against epsilon; output_scale defaults to 1 to match the original plots. A search-limit result is not a located threshold. Representation-theorem admissibility must still be checked separately.

## Reproduce the documents and figures

Python dependencies: `mpmath`, `numpy`, `scipy`, `matplotlib`, and `pypdf`. A LaTeX engine (`pdflatex` or `tectonic`) is required for PDFs.

```sh
python reproduce_figures.py
python check_math.py
python build_review.py
```

Alternatively specify `python build_review.py --engine /path/to/tectonic`. The builder checks overfull boxes and unresolved references, and records the actual page counts in `verification.json`; it imposes no main-section page target.

High-precision checks cover the replica/pole bridge, tail bound, normalized small-angle limit, logarithmic threshold sensitivity, and the standalone selector. They supplement the written proofs.
