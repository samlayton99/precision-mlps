"""Select lambda from an activation and precision, optionally a target summary.

Standard library only. Inputs use angular frequencies (radians per input unit).
This is a practical selector. The tanh representation theorem also requires
admissible geometry and width; a mean frequency is not an alias certificate.
"""
from __future__ import annotations

import math
import sys


def log_khat(activation: str, xi: float) -> float:
    """log(Khat(xi)/Khat(0)), evaluated without Fourier-tail underflow."""
    if activation == "gaussian":
        return -xi * xi / 4
    if activation != "tanh":
        raise ValueError("activation must be 'tanh' or 'gaussian'")
    a = abs(xi) * math.pi / 2
    if a == 0:
        return 0.0
    return math.log(2 * a) - a - math.log(-math.expm1(-2 * a))


def log_alias_score(activation: str, lam: float, theta: float | None = None) -> float:
    """Basic score if theta is omitted; the full anchored R otherwise."""
    if theta is None:
        return log_khat(activation, 2 * math.pi / lam)
    if not 0 < theta < math.pi:
        raise ValueError("The representative grid frequency h*mean_omega must be in (0, pi)")
    r = {"tanh": 1, "gaussian": 0}[activation]
    minus, plus = 2 * math.pi - theta, 2 * math.pi + theta
    terms = [r * math.log(theta / t) + log_khat(activation, t / lam)
             for t in (minus, plus)]
    high, low = max(terms), min(terms)
    numerator = high + math.log1p(math.exp(low - high))
    denominator = min(0.0, log_khat(activation, theta / lam))
    log_rho = (log_khat(activation, (4 * math.pi - theta) / lam)
               - log_khat(activation, minus / lam))
    if log_rho >= 0:
        raise ValueError("The geometric tail bound requires rho < 1")
    return math.log(2) + numerator - denominator - math.log(-math.expm1(log_rho))


def choose_lambda(activation: str, *, spacing: float,
                  epsilon: float = sys.float_info.epsilon,
                  spectral_mass: float | None = None,
                  mean_omega: float | None = None,
                  output_scale: float = 1.0,
                  interval: tuple[float, float] = (0.03, 1.5)) -> dict:
    """Return {'lambda', 'gamma', 'status', 'rule'} for the stated search interval.

    With no target summary, solve the basic kernel equation. To refine, supply
    both spectral_mass=S and mean_omega=omega_bar; the relative budget uses
    S/output_scale. For a sine mixture, S is the sum of absolute amplitudes and
    omega_bar their amplitude-weighted mean angular frequency. Width N on
    [-1,1] corresponds to spacing=2/N. Search limits are explicit practical
    bounds; 'upper_search_limit' is not a located threshold.
    """
    if activation not in ("tanh", "gaussian"):
        raise ValueError("activation must be 'tanh' or 'gaussian'")
    lo, hi = interval
    if not (0 < lo < hi and 0 < epsilon < 1 and spacing > 0 and output_scale > 0):
        raise ValueError("Invalid search interval, epsilon, spacing or output scale")
    if not all(math.isfinite(x) for x in (lo, hi, epsilon, spacing, output_scale)):
        raise ValueError("Inputs must be finite")
    if (spectral_mass is None) != (mean_omega is None):
        raise ValueError("Supply both spectral_mass and mean_omega, or neither")
    theta, shift = None, 0.0
    if spectral_mass is not None:
        if not (spectral_mass > 0 and mean_omega > 0
                and math.isfinite(spectral_mass) and math.isfinite(mean_omega)):
            raise ValueError("Target summaries must be positive and finite")
        theta = spacing * mean_omega
        shift = math.log(spectral_mass) - math.log(output_scale)
    rule = "basic" if theta is None else "refined"
    budget = math.log(epsilon)
    def score(lam):
        return shift + log_alias_score(activation, lam, theta)
    if score(lo) >= budget:
        return {"lambda": None, "gamma": None, "status": "no_feasible_point", "rule": rule}
    if score(hi) < budget:
        return {"lambda": hi, "gamma": hi / spacing,
                "status": "upper_search_limit", "rule": rule}
    for _ in range(80):
        mid = (lo + hi) / 2
        if mid == lo or mid == hi:
            break
        if score(mid) < budget:
            lo = mid
        else:
            hi = mid
    return {"lambda": lo, "gamma": lo / spacing, "status": "threshold", "rule": rule}


if __name__ == "__main__":
    import json
    print(json.dumps({
        "basic": choose_lambda("tanh", spacing=2/128),
        "sine_mixture": choose_lambda("tanh", spacing=2/128,
                                       spectral_mass=7/4, mean_omega=15*math.pi/7),
    }, indent=2))
