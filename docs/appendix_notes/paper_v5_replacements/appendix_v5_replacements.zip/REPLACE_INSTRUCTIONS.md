# Replacement instructions for paper version 5

Use these as **five complete replacement files**. Keep your existing Overleaf filenames and folders: open the corresponding file, select all, and paste the entire replacement. Nothing needs to be placed next to `main.tex`.

The download names below identify the replacements; they do not require renaming your existing files.

| Find this label in your existing appendix file | Replace the whole file with |
|---|---|
| `\label{app:construction-theory}` | `construction_appendix.tex` |
| `\label{sec:qi-bandwidth}` | `bandwidth_appendix.tex` |
| `\label{app:comparison-bounds}` | `comparison_bounds_appendix.tex` |
| `\label{app:pbit-solver}` | `precision_solver_appendix.tex` |
| `\label{app:circuit-error}` | `circuit_error_appendix.tex` |

If the circuit material is currently pasted directly into the parent document rather than stored in its own file, replace that entire subsection with `circuit_error_appendix.tex` instead.

## Inclusion order

In the file that currently includes the appendix, put the **existing** input lines in this order, retaining their current paths:

1. Construction.
2. Bandwidth.
3. Comparison bounds and measured comparison.
4. Precision-controlled solver **and the new Theorem 3.2 proof**.
5. Circuit error propagation.

Thus, swap the bandwidth and comparison input lines if comparison currently comes first. The construction file itself now runs: setup → tanh reference construction → recovery and continuous error → GELU/SiLU extension.

**The Theorem 3.2 proof is already appended to the solver replacement. Do not add a sixth input line or paste that proof a second time.** The existing solver subsection is unchanged; the new proof starts at `\label{app:note-spectrum}`. This packaging keeps your five-file arrangement.

The construction replacement preserves its existing `\appendix` command. There must be only one active `\appendix` at this location; do not add another in the parent document. All existing construction labels are retained, so automatic section references will follow the reordered sections.

## References to fix in the main text

Search for the indicated sentence or location, then use these labels:

| Main-text location | Reference to use |
|---|---|
| Theorem 3.1: “The full proof and formal theorem statement” | `Appendix~\ref{app:construction-theory}` |
| Section 3.3, after the bandwidth prediction: “gives the derivation” | `Appendix~\ref{sec:qi-bandwidth}` |
| Theorem 3.2: “The explicit gamma-dependent rate bounds” | `Appendix~\ref{app:note-spectrum}` |
| Section 3.4: the paragraph about the continuous analogue and Fourier integral | `Appendix~\ref{app:note-spectrum}` |
| Section 3.4: the sentence ending with the width-153, `5.85\times10^{-4}` example | `Appendix~\ref{app:note-step-example}` |
| Figure 3: “intervals from Theorem” | `Theorem~\ref{thm:note-rates}` |

Keep `\label{thm:note-output}` on main-text Theorem 3.2. It is the label used by the new appendix proof. Do not create a second copy of the main theorem.

Figure 3's **width-512 geometry/protocol reference** still needs its own protocol subsection. Do not point it to `app:note-step-example`: that example has width 153, 263 samples, and a different mixed-sine target.

## Figures and packages

Keep these existing image files in their current locations:

- `figures/appendix/bandwidth_width_rules.png`
- `figures/appendix/bandwidth_error_rules.png`
- `figures/appendix/comparison_results.png`

The bandwidth replacement already includes both bandwidth figures. If your parent document also separately inputs `bandwidth_figures_only.tex`, **remove that extra input line**; keep the image files. Otherwise the same figures and labels will appear twice.

The replacements use the paper's existing math, theorem, citation, and graphics support. They add no new package requirement. Keep `graphicx`, `amsmath`, `amssymb`, and your existing theorem/proof definitions in the preamble.

## What changed

- Construction: ten peer subsections become four. Recovery follows the tanh construction; GELU/SiLU follows the common recovery argument. Shared assumptions are stated explicitly before use. All 138 display-math blocks, all 18 proof environments, and all 155 original construction labels are preserved.
- Bandwidth: repeated setup is shortened. A compact transform table and the general/refined rules are added so the existing tanh/GELU/SiLU/erf figures have their formulas stated. The original proof and its heuristic qualifications remain.
- Comparison: only redundant prose is trimmed; the derivations and existing measured-comparison figure remain.
- Solver: the supplied solver subsection is unchanged. The condensed Theorem 3.2 appendix follows it and defines every correction, proves the finite-network rate enclosure, and derives the residual and step bounds.
- Circuits: recursive error bounds are defined by equality, making the polynomial argument valid. The domain assumption and final conclusion remain.

Theorem 3.3 is intentionally not added or revised.

## Checks

The five replacements compile together with the existing figures. No duplicate labels or unresolved local references remain. The compile check used a temporary wrapper, with main-paper references and bibliography entries supplied as placeholders; the full paper's source and bibliography were not supplied. A local font-cache substitution in that wrapper affects no delivered file. The new finite-kernel proof received an independent mathematical review, and the activation rules were checked against the plotting implementation.

See `REMAINING_ISSUES.md` for issues that require changes outside these replacement files.
