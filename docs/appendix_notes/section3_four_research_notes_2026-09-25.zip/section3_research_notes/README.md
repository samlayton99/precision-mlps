# Four research notes for Section 3

Revised 25 September 2026. These are source notes to clean up and fold into a future appendix. They are not four papers, and this folder does not assemble the appendix itself.

| Note | PDF | Editable LaTeX | What it adds |
|---|---|---|---|
| 1. True-p-bit implementation | [PDF](01_true_pbit_implementation.pdf) | [LaTeX](01_true_pbit_implementation.tex) | The arithmetic contract, operation order, solver cutoff, native-format checks, and completed expC11 evidence. This complements the supplied scaled-FP64 recovery proof; it describes a different implemented computation. |
| 2. Finite-kernel ratios | [PDF](02_finite_kernel_ratios.pdf) | [LaTeX](02_finite_kernel_ratios.tex) | The continuous-center decomposition, two-sided bounds for the finite kernel, normalization by the largest eigenvalue, and the conversion to necessary and sufficient readout training times. Includes the existing figures and qualifications on the finite-geometry corrections. |
| 3. Geometry and readout | [PDF](03_geometry_readout.pdf) | [LaTeX](03_geometry_readout.tex) | The exact loss split, evidence that increasing the geometry learning rate or amplifying the approximation-floor gradient improves geometry, the Fourier/readout signal calculation, and finite-horizon movement budgets. |
| 4. General activation bandwidth selection | [PDF](04_activation_bandwidth.pdf) | [LaTeX](04_activation_bandwidth.tex) | The ratio of Fourier transforms of localized activation derivatives, its derivation from repeated lattice spectra, exact lattice least-squares error, frequency-dependent refinement, and formulas for tanh, sigmoid, exact GELU, SiLU, Gaussian, and sech-squared activations. |

## Changes from the earlier packet

- The bandwidth note has been replaced. It is now the general derivative-Fourier-ratio argument, not another presentation of the supplied finite-contour tanh theorem.
- The geometry note leads with the successful learning-rate interventions. It distinguishes actual trained-readout error from the error after a least-squares refit, and separates exact identities, measured behavior, and a still-conditional causal account of geometry stalling.
- The neighboring/readout-conditioning note is excluded.
- The implementation and finite-kernel notes retain their reviewed content and are explicitly labeled research notes.

These additions are complementary, not disjoint sentence by sentence. They restate definitions needed for standalone reading. In particular, the finite-kernel note expands an argument already appearing in the current draft, and the bandwidth note shares the tanh special case with the supplied material. Its additional content is the general activation derivation and selector, not a second finite-tanh proof.

## Evidence and limitations

All numerical figures and training outcomes are recovered from existing work. No training or experimental sweep was run for this revision. The PDFs distinguish proved inequalities from ordinary floating-point evaluations and reported experimental results. The bandwidth note does not transfer a finite-domain tanh theorem to arbitrary activations. The geometry note does not claim that the Fourier argument alone proves failure of joint training.

Each note identifies its primary sources. The broader recovered source inventory remains in `docs/appendix_materials/2026-09-25/` in the repository. This packet includes the figures needed to compile these four documents, rather than copying the entire historical archive.

## Rebuilding

All four PDFs were compiled directly from their accompanying LaTeX. With `tectonic` or `pdflatex` installed, run `bash build.sh` from this folder. Standard LaTeX packages are required; no bibliography download or experiment data is needed. The `figures/` directory must remain alongside the source files.

`MANIFEST.json` records the packet's file hashes. The ZIP contains this folder's four PDFs, four LaTeX sources, figures, build script, and index; compilation logs and temporary files are omitted.
